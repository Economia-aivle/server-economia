document.addEventListener('DOMContentLoaded', function() {
    // 페이지 로드 시 별도의 동영상 URL을 가져오지 않음
    console.log('Page loaded with fixed video URL.');
});