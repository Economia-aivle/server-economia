from rest_framework import serializers
from economia.models import Player
from rest_framework_simplejwt.tokens import RefreshToken

class ProductSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    player_id = serializers.CharField(max_length=20)
    password = serializers.CharField(max_length=255)
    

class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=64)
    password = serializers.CharField(max_length=64, write_only=True)

    def validate(self, data):
        username = data.get("username", None)
        password = data.get("password", None)

        if Player.objects.filter(player_id=username).exists():
            user = Player.objects.get(player_id=username)
            if not user.check_password(password):
                raise serializers.ValidationError("Incorrect password")
        else:
            raise serializers.ValidationError("User does not exist")
        
        token = RefreshToken.for_user(user=user)
        data = {
            'id': user.id,
            'nickname': user.nickname,
            'refresh_token': str(token),
            'access_token': str(token.access_token)
        }
        return data